function test(){
	return alert("JS is Installed");
	
}

function makeactive() {
     return document.forms['joobleseachform'].elements['query'].focus();
       
}

function removeborder(){
  
          document.getElementById("textinput").style.outline="white";
          //document.getElementById("line").innerHTML="<hr>";
          
        
        }
     